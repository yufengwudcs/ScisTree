How to prepare inputs for Scistree from sequence reads?
Yufeng Wu (yufeng.wu@uconn.edu)
May 12, 2019

Note: some of the distributed files may be overwritten if you follow the step-by-step instructions. You may want to save a copy of these files before starting to run the code.

****** Dependencies

samtools: I assume samtools path is set properly
Monovar: be careful about setting the path of Monovar.
scistree: you should create a link to the ScisTree executable in the current directory.
scprob: this is a small tool written by myself. I recommend to compile scprob yourself: 
            g++ SCProb-v1.2.0.cpp -o scprob-v1.2.0
        the provided scprob executable was built on Linux 64.

****** Data files

There are five BAM files, each for a cell. These files are named as: reads-sc-c1.bam, reads-sc-c2.bam, etc.
You should use samtools to sort and index these BAM files.

Since GitHub doesn't allow large files, the sorted BAM files are provided in a separate zip file. This is only for your convenience. You can certainly use samtools to create sorted BAM files yourself.

You also need a reference genome file in fasta format. In this example, this is chr20.clean.mid.fa. Note you need to index the genome first before use. See the related files for chr20.clean.mid.fa. 

****** Running Monovar

You need to call single nucleiotide variants (SNVs) from the given BAM files. In this example, we use Monovar. Note that you need to test to make sure Monovar works properly before continuing. My experience shows that one may encounter problems in Monovar setup (e.g. Python settings). I cannot provide more specific instructions since I am not the author of that tool.

You need to create a file that contains the list of BAM files to be used by Monovar. In this example, the file is list-bam-files.txt. This file contains one BAM file per line. 

Now execute the following:

samtools mpileup -BQ0 -d10000 -f  chr20.clean.mid.fa  -q 40 -b list-bam-files.txt | monovar.py -p 0.002 -a 0.2 -t 0.05 -m 1 -f chr20.clean.mid.fa  -b list-bam-files.txt -o output.vcf 

Here, there are various parameters you can change. This can be a little confusing to choose these parameters. Check out Monovar documentation to determine if you want to change the settings used above.

Now you should have the called SNV file. In this example, that is output.vcf.

****** Generate probability from the VCF file

There are two ways to generate genotype probabiity matrix from VCF file.

-----(a) Use genotype probabilities calculated by Monovar directly
The VCF file has the genotype probability for each cell at each site. For your conveneience, I have written a AWK script to convert the VCF format to the format used by Scistree. In this example, do:

awk -f convMonovarOutputToHapProb-v1.2.0.awk c=5 t=1 output.vcf > monovar-direct-out.probs

The file monovar-direct-out.probs contains the correct Scistree v1.2.0 input. Try:

./scistree monovar-direct-out.probs

and you should see the code now works.

Here, c is the number of cells (5 in this case) and t is the threshold for whether using this site or not (the minimum number of cells containing mutants): if setting to 1, it means using all sites. If t=2, that means you only use sites that have at least two mutant cells (and thus it will use fewer sites). Try it yourself: if you choose t=2, you only have 16 sites left.

-----(b) Alternatively, you can use third-party tool to compute the genotype probabiity from reads counts. In this example, I will use a small tool called scprob to do this. You can try other tools as well. 

To do this, you first generate the allele counts file as:

awk -f convMonovarOutputToAlleleCounts.awk c=5 output.vcf > tmp-scprob-monvovar-out.allele.counts

Again, c is the number of cells.

Then, you invoke scprob with the allele counts to calculate the probabilities.

./scprob-v1.2.0 tmp-scprob-monvovar-out.allele.counts > monovar-scprob-out.probs

Then you run ScisTree:

./scistree monovar-scprob-out.probs

Now try to play with the parameter settings of ScisTree. For example, the -t option is something you may want to experiement with:

./scistree -t 0.9  monovar-scprob-out.probs

