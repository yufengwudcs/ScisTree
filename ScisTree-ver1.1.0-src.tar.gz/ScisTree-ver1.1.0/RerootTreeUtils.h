//
//  RerootTreeUtils.h
//  
//
//  Created by Yufeng Wu on 8/10/18.
//
//

#ifndef RerootTreeUtils_h
#define RerootTreeUtils_h

#include <string>

std::string ReRootTreeNewick( char *nwFile, char *taxaNewRoot );


#endif /* RerootTreeUtils_h */
